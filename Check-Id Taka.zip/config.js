const config = {
   higsDomino: false, /// Ubah jadi true jika ingin mengaktifkan
};

module.exports = config;
