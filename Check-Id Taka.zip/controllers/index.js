const getZoneController = require('./getZone.controller');
const idCheckController = require('./idcheck.controller');

module.exports = {
   getZoneController,
   idCheckController,
};
